# Library-Management-System
HTML,Javascript,PHP project. It is a minor project. 

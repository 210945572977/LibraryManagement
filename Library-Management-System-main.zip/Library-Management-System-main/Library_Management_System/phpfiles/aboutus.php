<html>
	<head>
	<style>
		*{
			font-family:Garamond;
		}
		body{
			background-color:rgba(245,150,150,0.4);
		}
		h2{
			font-size:35px;	
			border-right:2px outset;
			border-bottom:2px ridge;
			width:200px;
		}
		hr{
			margin-top:70px;
			border-bottom:2px double;
			width:50em;
		}
		p{
			font-size:20px;
		}	
	</style>
	</head>
	<body>
		
			<div><h2>About Us</h2></div>
			<p>Library management system is all about organizing, managing the library and library-oriented tasks.
			This system maintains the record of books and student.</p>
			
			<p>The owner can easily update, delete and insert data in the database.Library Management System 
			aims at developing a fully functional computerized system to maintain all the day to day activity of a library.
			This System is secure and manages the entire application’s authorization and authentication, not any intruder can 
			login and modify the data, as admin can only login into the system.</p>
			
			<p>This system can add and modify student information and manages the data regarding to books that which book is
			issued and which is return.Also add data of newly added books.There is also the facility to search particular book.</p>	
			<hr>
	</body>
</html>